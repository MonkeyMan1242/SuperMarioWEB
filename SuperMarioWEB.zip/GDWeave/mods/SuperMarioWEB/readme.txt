Thanks for playing with SuperMarioWEB!

Fish up familiar aquatic foes from Mario's past in this content mod for WEBFISHING!

Version: 1.0.0
Authors: MonkeyMan1242
https://github.com/MonkeyMan1242/SuperMarioWEB

This mod was made with Hatchery 1.2.0
https://github.com/coolbot100s/Hatchery